package com.techpacs.greenhouse;

public class Constants {
   //   public final static String SERVER_NAME = "https://iot0606.000webhostapp.com/";
   public final static String SERVER_NAME = "https://www.techpacs.com/";
   

}
