package com.techpacs.greenhouse.models;

public class DataModifiedModel {
    FieldModel field1;
    FieldModel field2;
    FieldModel field3;
    FieldModel field4;
    FieldModel field5;
    FieldModel field6;
    FieldModel field7;
    FieldModel field8;
    FieldModel field9;

    public FieldModel getField1() {
        return field1;
    }

    public FieldModel getField2() {
        return field2;
    }

    public FieldModel getField3() {
        return field3;
    }

    public FieldModel getField4() {
        return field4;
    }

    public FieldModel getField5() {
        return field5;
    }

    public FieldModel getField6() {
        return field6;
    }

    public FieldModel getField7() {
        return field7;
    }

    public FieldModel getField8() {
        return field8;
    }

    public FieldModel getField9() {
        return field9;
    }
}
