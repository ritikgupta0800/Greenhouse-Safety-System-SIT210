package com.techpacs.greenhouse.models;

public
class FieldModel {
    String value;
    String last_update_time;

    public String getValue() {
        return value;
    }

    public String getLast_update_time() {
        return last_update_time;
    }
}
