package com.techpacs.greenhouse.models;

public class ResponseModel {
   String message;
   String id;
}
